package kr.hkit.pms.mapper.project;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface Project {
	// 임시로 생성한 인터페이스
}
