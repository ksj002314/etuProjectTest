package kr.hkit.pms.domain.project;

import lombok.Data;

@Data
public class Project {
	// 임시로 생성한 클래스
}
