package kr.hkit.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitPms2Application {

	public static void main(String[] args) {
		SpringApplication.run(KitPms2Application.class, args);
	}

}
