package kr.hkit.pms.service.material;

import java.util.List;

import kr.hkit.pms.domain.material.SoftwareMgtDTO;

public interface MaterialSoftwareServive {
	// 임시로 생성한 인터페이스
	
	
	public List<SoftwareMgtDTO> getAll();
}
