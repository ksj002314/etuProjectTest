package kr.hkit.pms.service.board;

public interface RefBoardService {

}
