package kr.hkit.pms.service.board;

import org.springframework.stereotype.Service;
//
//@Service
//public class RefBoardImpl implements FreeBoard{
//
//}
