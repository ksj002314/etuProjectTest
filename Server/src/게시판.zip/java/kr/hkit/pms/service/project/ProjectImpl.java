package kr.hkit.pms.service.project;

import org.springframework.stereotype.Service;

@Service
public class ProjectImpl implements Project {
	// 임시로 생성한 클래스
}
