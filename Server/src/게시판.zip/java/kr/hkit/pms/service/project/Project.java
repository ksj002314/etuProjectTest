package kr.hkit.pms.service.project;

public interface Project {
	// 임시로 생성한 인터페이스
}
